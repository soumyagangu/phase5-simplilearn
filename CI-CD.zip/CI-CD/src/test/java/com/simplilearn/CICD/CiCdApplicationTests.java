package com.simplilearn.CICD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CiCdApplicationTests {

	@Test
	void contextLoads() {
	}

}
